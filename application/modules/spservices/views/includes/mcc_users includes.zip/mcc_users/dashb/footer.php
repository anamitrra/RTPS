<!-- /.content-wrapper -->
<footer class="main-footer">
    <span>Copyright &copy; 2020-2022 <a href="nic.in">Government of Assam. All Rights Reserved</a>
    </span>
    <div class="float-right d-none d-sm-inline-block">
        <span>Designed & Developed by: National Informatics Centre, Assam.</span>
    </div>
</footer>
</div>
</div>
<script src="<?= base_url("assets/"); ?>dist/js/adminlte.js"></script>
</body>
</html>
