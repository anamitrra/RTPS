<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title><?php echo SITE_TITLE; ?></title>
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?= base_url("assets/"); ?>plugins/fontawesome-free/css/all.min.css"> <!-- Ionicons -->
  <link rel="stylesheet" href="<?= base_url("assets/"); ?>dist/css/adminlte.min.css">
  <link rel="stylesheet" href="<?= base_url("assets/css/"); ?>custom.css">
  <link rel="stylesheet" href="<?= base_url("assets/"); ?>plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="<?= base_url("assets/"); ?>plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <link defer href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  <!-- PAGE LEVEL STYLES-->
  <!-- jQuery -->
  <script src="<?= base_url("assets/"); ?>plugins/jquery/jquery.min.js"></script>
  <script src="<?= base_url("assets/"); ?>plugins/jquery-ui/jquery-ui.min.js"></script>
  <script src="<?= base_url("assets/"); ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?= base_url("assets/"); ?>plugins/moment/moment.min.js"></script>
  <script src="<?= base_url("assets/"); ?>plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
  <script src="<?= base_url("assets/"); ?>plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
  <style>
    [class*='sidebar-dark-'] {
      background-color: #1a4066 !important;
      /* background-color: #343a40; */
    }
  </style>
</head>

<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">
    <?php $this->load->view("includes/mcc_users/dashb/topbar") ?>
    <?php $this->load->view("includes/mcc_users/dashb/sidebar") ?>
    <p class="text-right px-4 my-1">Logged in as :
      <?php
      $role = $this->session->userdata('admin')['role'];
      if($role == 'SA'){
        echo '<span class="text-danger">State Administrator</span>';
      }
      else if($role == 'DA'){
        echo '<span class="text-danger">District Administrator</span> | <span class="text-info">'.$this->session->userdata('admin')['district'].'</span>';

      }
      ?></p>
    <!-- /.navbar -->